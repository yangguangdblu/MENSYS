The file
  python2.7.dll
is a static dll which is stored here to allow running
the Python examples in Buildings.Utilities.IO.Python27
on Dymola 2014 Beta1 on Windows.
This is a dummy 32 bit dll which is needed
to accommodate the work around described in ../linux32

March 27, 2013, tsnouidui@lbl.gov
